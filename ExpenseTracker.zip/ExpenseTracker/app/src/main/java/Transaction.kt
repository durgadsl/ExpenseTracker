package com.alterpat.budgettracker

data class Transaction( ) {
}