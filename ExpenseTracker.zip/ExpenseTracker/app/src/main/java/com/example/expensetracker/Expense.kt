package com.example.expensetracker

data class Expense(
    val amount: Double,
    val note: String
)
